# Laptop Gallery — Setup Guide

Ye guide aapko poora system live karne me step-by-step madad karega. Koi coding knowledge nahi chahiye, bas neeche diye steps follow karein.

---

## File list (ye sab files ek hi folder me rakhni hain)

- `index.html` — website ka structure
- `style.css` — design
- `app.js` — poora logic (login, inventory, cash ledger, reports)
- `firebase-config.js` — ⚠️ isme apna Firebase config dalna hoga (Step 2 me bataya hai)
- `firestore.rules` — security rules (Step 4 me Firebase console me paste karni hai)

---

## Step 1 — Firebase project banayein

1. [console.firebase.google.com](https://console.firebase.google.com) par jayein, Google account se login karein.
2. **"Add project" / "Create a project"** par click karein.
3. Project ka naam dein — jaise `laptop-gallery`. Continue karein.
4. Google Analytics ka option aayega — isko **off/skip** kar dein (zaroorat nahi hai). Project create karein.

---

## Step 2 — Web app add karein aur config copy karein

1. Project dashboard khulega. Wahan **`</>`** (web) icon par click karein "Add app" section me.
2. App ka nickname dein — jaise `Laptop Gallery Web`. **Firebase Hosting set up karne ka checkbox chhod dein abhi** (uncheck rehne dein).
3. "Register app" par click karein.
4. Aapko ek code dikhega jisme `const firebaseConfig = { ... }` hoga. Sirf is object ke andar wali values copy karni hain:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "laptop-gallery-xxxx.firebaseapp.com",
  projectId: "laptop-gallery-xxxx",
  storageBucket: "laptop-gallery-xxxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456"
};
```

5. Ye values `firebase-config.js` file me jakar `YOUR_API_KEY`, `YOUR_PROJECT_ID` waghera ki jagah paste kar dein. Poora object replace kar dena hai.
6. "Continue to console" par click karke wapas dashboard par aa jayein.

---

## Step 3 — Authentication (login) enable karein

1. Left sidebar me **Build > Authentication** par jayein.
2. "Get started" par click karein.
3. **Sign-in method** tab me, **Email/Password** par click karein, **Enable** karein, Save karein.

Bas itna hi — login/signup system khud kaam karega.

---

## Step 4 — Firestore Database (data storage) enable karein

1. Left sidebar me **Build > Firestore Database** par jayein.
2. "Create database" par click karein.
3. Location select karein (koi bhi nearby region — jaise `asia-south1 (Mumbai)`). Next.
4. **"Start in production mode"** select karein. Enable karein.
5. Database ban jaane ke baad, top par **"Rules"** tab par click karein.
6. Wahan jo bhi rules likhi hain unko select karke delete kar dein, aur `firestore.rules` file ka **pura content copy-paste** kar dein.
7. **Publish** button dabayein.

Ye rules ensure karti hain ke sirf wahi log data dekh/badal sakein jinhe aapne approve kiya hai.

---

## Step 5 — Website ko live karein (hosting)

Sabse aasan tareeka — **Netlify Drop** (free, 2 minute ka kaam):

1. [app.netlify.com/drop](https://app.netlify.com/drop) par jayein.
2. Apni saari files (`index.html`, `style.css`, `app.js`, `firebase-config.js`) ek folder me rakhein (firestore.rules ki zaroorat website me nahi, wo sirf Firebase console ke liye thi).
3. Us folder ko Netlify Drop ke page par **drag & drop** kar dein.
4. Kuch second me ek live link mil jayega (jaise `random-name-123.netlify.app`) — yahi link aap jisko bhi dena chahein de sakte hain.

> Agar aap chaahein to baad me Netlify par free account banakar custom domain (jaise `laptopgallery.com`) bhi laga sakte hain.

**Alternative:** Firebase Hosting bhi use kar sakte hain agar comfortable ho command line se, lekin Netlify Drop sabse simple hai bina coding background ke.

---

## Step 6 — Pehla account (Admin) banayein

1. Apni live website kholein.
2. **"Sign up karein"** par click karke apna naam, email, password se account banayein.
3. **Sabse pehla signup automatically Admin ban jaata hai aur seedha approved hota hai** — aapko kuch aur nahi karna.
4. Login kar lein — dashboard khul jayega.

---

## Step 7 — Staff ko access dena

1. Jis staff/family member ko access dena hai, unhe apni website ka link bhejein.
2. Wo "Sign up karein" karke account banayenge — unka status "Pending approval" rahega, wo login nahi kar payenge jab tak aap approve na karein.
3. Aap (admin) login karke sidebar me **"Users manage karein"** par jayein.
4. Wahan unki request "Pending approvals" me dikhegi — **"Approve"** dabayein.
5. Ab wo login kar sakte hain aur live data dekh/edit kar sakte hain.

Jab chahein, "Users manage karein" se kisi ka access bhi hata sakte hain (Remove button).

---

## Kaise use karein (quick overview)

- **Dashboard** — overall stock, sales, is mahine ka cash in aur profit ek nazar me.
- **Inventory** — saare laptops ki list, search/filter karke dekhein. "Bechein" button se sale record karein (date, price, customer).
- **Naya laptop add karein** — Brand, Model, Serial No., Buy Date, Buy Price, Supplier sab bharein.
- **Cash ledger** — har cash in/out manually bhi add kar sakte hain (jab koi laptop bikta hai to cash-in entry khud-ba-khud ban jaati hai).
- **Reports** — total investment, revenue, profit, aur brand-wise breakdown.

Sab data Firebase Firestore me real-time save hota hai — jisko bhi aap access doge, wo apne phone/laptop se same data live dekh sakega.

---

## Koi problem aaye to

- Login error aaye → Email/Password authentication enable hai ya nahi Step 3 me check karein.
- Data save na ho / "permission denied" error → Firestore rules sahi se publish hui ya nahi Step 4 me check karein, aur aapka account "approved" status me hai ya nahi check karein.
- Website blank dikhe → Browser console (F12) me error dekhein, ya `firebase-config.js` me values sahi se paste hui ya nahi check karein.
